﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 2: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 7 de abril de 2024
 */

/*La clase Artículo se hace de manera homóloga a las clases
 anteriores. Para esta clase se agrega un atributo de la
clase Categoría. Se crean los atributos, métodos set y get
y constructores.*/

namespace Entidades
{
    public class Articulo
    {
        // Atributos privados
        private int IDArticulo_privado;
        private string NombreArticulo_privado;
        private int PrecioArticulo_privado;
        private Categoria_Articulo Categoria_Articulo_privado;

        // Métodos set y get para los atributos
        public int IDArticulo
        {
            get { return IDArticulo_privado; }
            set { IDArticulo_privado = value; }
        }

        public string NombreArticulo
        {
            get { return NombreArticulo_privado; }
            set { NombreArticulo_privado = value; }
        }

        public int PrecioArticulo
        {
            get { return PrecioArticulo_privado; }
            set { PrecioArticulo_privado = value; }
        }

        public Categoria_Articulo Categoria_Articulo
        {
            get { return Categoria_Articulo_privado; }
            set { Categoria_Articulo_privado = value; }
        }
        //Constructor con sus parámetros
        public Articulo()
        {

        }
    }
}
