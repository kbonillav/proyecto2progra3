﻿namespace Presentacion
{
    partial class Ventana_Registrar_Cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            entrada1_cliente = new TextBox();
            label3 = new Label();
            entrada2_cliente = new TextBox();
            label4 = new Label();
            entrada3_cliente = new TextBox();
            entrada4_cliente = new TextBox();
            label5 = new Label();
            label6 = new Label();
            entrada5_cliente = new TextBox();
            label7 = new Label();
            entrada6_cliente = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(155, 24);
            label1.Name = "label1";
            label1.Size = new Size(182, 15);
            label1.TabIndex = 0;
            label1.Text = "Ingrese la información del cliente";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(38, 75);
            label2.Name = "label2";
            label2.Size = new Size(192, 15);
            label2.TabIndex = 1;
            label2.Text = "Ingrese la identificación del cliente:";
            // 
            // entrada1_cliente
            // 
            entrada1_cliente.Location = new Point(247, 72);
            entrada1_cliente.Name = "entrada1_cliente";
            entrada1_cliente.Size = new Size(208, 23);
            entrada1_cliente.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(38, 128);
            label3.Name = "label3";
            label3.Size = new Size(162, 15);
            label3.TabIndex = 3;
            label3.Text = "Ingrese el nombre del cliente:";
            // 
            // entrada2_cliente
            // 
            entrada2_cliente.Location = new Point(206, 125);
            entrada2_cliente.Name = "entrada2_cliente";
            entrada2_cliente.Size = new Size(249, 23);
            entrada2_cliente.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(38, 180);
            label4.Name = "label4";
            label4.Size = new Size(200, 15);
            label4.TabIndex = 5;
            label4.Text = "Ingrese el primer apellido del cliente:";
            // 
            // entrada3_cliente
            // 
            entrada3_cliente.Location = new Point(247, 177);
            entrada3_cliente.Name = "entrada3_cliente";
            entrada3_cliente.Size = new Size(208, 23);
            entrada3_cliente.TabIndex = 6;
            // 
            // entrada4_cliente
            // 
            entrada4_cliente.Location = new Point(255, 232);
            entrada4_cliente.Name = "entrada4_cliente";
            entrada4_cliente.Size = new Size(200, 23);
            entrada4_cliente.TabIndex = 7;
            entrada4_cliente.TextChanged += textBox4_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(38, 235);
            label5.Name = "label5";
            label5.Size = new Size(211, 15);
            label5.TabIndex = 8;
            label5.Text = "Ingrese el segundo apellido del cliente:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(38, 288);
            label6.Name = "label6";
            label6.Size = new Size(252, 15);
            label6.TabIndex = 9;
            label6.Text = "Ingrese la fecha de nacimiento (aaaa-mm-dd):";
            // 
            // entrada5_cliente
            // 
            entrada5_cliente.Location = new Point(296, 285);
            entrada5_cliente.Name = "entrada5_cliente";
            entrada5_cliente.Size = new Size(159, 23);
            entrada5_cliente.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(38, 340);
            label7.Name = "label7";
            label7.Size = new Size(361, 15);
            label7.TabIndex = 11;
            label7.Text = "Indique el género del cliente (M para masculino o F para femenino)";
            // 
            // entrada6_cliente
            // 
            entrada6_cliente.Location = new Point(405, 337);
            entrada6_cliente.Name = "entrada6_cliente";
            entrada6_cliente.Size = new Size(50, 23);
            entrada6_cliente.TabIndex = 12;
            // 
            // button1
            // 
            button1.Location = new Point(38, 385);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 13;
            button1.Text = "Registrar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(206, 385);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 14;
            button2.Text = "Limpiar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(380, 385);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 15;
            button3.Text = "Volver";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Ventana_Registrar_Cliente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(482, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(entrada6_cliente);
            Controls.Add(label7);
            Controls.Add(entrada5_cliente);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(entrada4_cliente);
            Controls.Add(entrada3_cliente);
            Controls.Add(label4);
            Controls.Add(entrada2_cliente);
            Controls.Add(label3);
            Controls.Add(entrada1_cliente);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Ventana_Registrar_Cliente";
            Text = "Ventana_Registrar_Cliente";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox entrada1_cliente;
        private Label label3;
        private TextBox entrada2_cliente;
        private Label label4;
        private TextBox entrada3_cliente;
        private TextBox entrada4_cliente;
        private Label label5;
        private Label label6;
        private TextBox entrada5_cliente;
        private Label label7;
        private TextBox entrada6_cliente;
        private Button button1;
        private Button button2;
        private Button button3;
    }
}