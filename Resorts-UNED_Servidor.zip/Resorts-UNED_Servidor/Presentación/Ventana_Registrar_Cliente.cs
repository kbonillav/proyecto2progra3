﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/*Esta ventana implementa el método para registrar a los clientes en el sistema
 Se crea también la lógica para limpiar los campos y el retorno al menú principal.*/

using Entidades;
using Presentación;
using System.Globalization;

namespace Presentacion
{
    public partial class Ventana_Registrar_Cliente : Form
    {
        public Ventana_Registrar_Cliente()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cliente[] clientes = new Cliente[20];
            int indicecliente = 0;

            do
            {
                //Aqui se utiliza solamente el ciclo do while para verificar que el ID
                //del cliente ingresado sea único.
                string IDCliente_ingresado;
                IDCliente_ingresado = entrada1_cliente.Text;
                do
                {
                    if (Equals(IDCliente_ingresado, clientes[indicecliente]))
                    {
                        Console.WriteLine("ID de cliente repetido. Ingrese uno diferente");
                        IDCliente_ingresado = Console.ReadLine();
                        continue;
                    }
                }
                while (clientes.Any(c => c != null && c.IDCliente == IDCliente_ingresado));

                string Nombre_cliente = entrada2_cliente.Text;

                string PrimerApellido_cliente = entrada3_cliente.Text;

                string SegundoApellido_cliente = entrada4_cliente.Text;

                DateTime FechaNacimiento_cliente;
                do
                {
                    if (!DateTime.TryParseExact(entrada5_cliente.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out FechaNacimiento_cliente))
                    {
                        Console.WriteLine("Fecha inválida. No puede ingresar fechas futuras.");
                        continue;
                    }
                }
                while (FechaNacimiento_cliente > DateTime.Now); // Este ciclo se diseña para comprobar que la fecha de nacimiento no esté en el futuro.

                char Genero_cliente = char.Parse(entrada6_cliente.Text);

                //Se despliega el objeto creado
                clientes[indicecliente] = new Cliente(IDCliente_ingresado, Nombre_cliente, PrimerApellido_cliente, SegundoApellido_cliente, FechaNacimiento_cliente, Genero_cliente);

                Console.WriteLine("Customer created: {0}", clientes[indicecliente]);
                
                //Se actualiza el indice
                indicecliente++;

            }
            while (MessageBox.Show("Resultado", "Desea agregar otro cliente?", MessageBoxButtons.YesNo) == DialogResult.Yes && indicecliente < clientes.Length);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            entrada1_cliente.Text = String.Empty;
            entrada2_cliente.Text = String.Empty;
            entrada3_cliente.Text = String.Empty;
            entrada4_cliente.Text = String.Empty;
            entrada5_cliente.Text = String.Empty;
            entrada6_cliente.Text = String.Empty;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Ventana_Principal MenuPrincipal = new Ventana_Principal();
            MenuPrincipal.Show();
        }
    }

}
