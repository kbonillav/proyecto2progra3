﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos
{
    public static class ArticuloAD
    {
        private static Articulo[] articulos = new Articulo[20];
        private static int indicearticulo = 0;

        public static bool GuardarArticulo (Articulo NuevoArticulo) 
        {
            try
            {
                articulos[indicearticulo] = NuevoArticulo;
                indicearticulo++;
                return true;
            }
            catch (IndexOutOfRangeException)
            {
                throw new IndexOutOfRangeException("El repositorio esta lleno y no permite registrar más información");
            }
        }

        public static Articulo[] ConsultarArticulos() 
        { 
            return articulos; 
        }
    }
}
