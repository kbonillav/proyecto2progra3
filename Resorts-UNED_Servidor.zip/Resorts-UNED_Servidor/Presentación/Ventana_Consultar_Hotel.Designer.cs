﻿namespace Presentacion
{
    partial class Ventana_Consultar_Hotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            dgvConsultarHotel = new DataGridView();
            hotelBindingSource = new BindingSource(components);
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvConsultarHotel).BeginInit();
            ((System.ComponentModel.ISupportInitialize)hotelBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dgvConsultarHotel
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvConsultarHotel.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvConsultarHotel.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvConsultarHotel.DefaultCellStyle = dataGridViewCellStyle2;
            dgvConsultarHotel.Location = new Point(12, 23);
            dgvConsultarHotel.Name = "dgvConsultarHotel";
            dgvConsultarHotel.Size = new Size(544, 348);
            dgvConsultarHotel.TabIndex = 0;
            // 
            // hotelBindingSource
            // 
            hotelBindingSource.DataSource = typeof(Entidades.Hotel);
            // 
            // button1
            // 
            button1.Location = new Point(481, 377);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Ventana_Consultar_Hotel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(568, 415);
            Controls.Add(button1);
            Controls.Add(dgvConsultarHotel);
            Name = "Ventana_Consultar_Hotel";
            Text = "Ventana_Consultar_Hotel";
            Load += Ventana_Consultar_Hotel_Load;
            ((System.ComponentModel.ISupportInitialize)dgvConsultarHotel).EndInit();
            ((System.ComponentModel.ISupportInitialize)hotelBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvConsultarHotel;
        private BindingSource hotelBindingSource;
        private Button button1;
    }
}