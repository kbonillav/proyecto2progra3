/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* C�tedra de Tecnolog�a de Sistemas
* 
* 00830 Programaci�n Avanzada
* Proyecto 1: Sistema de Gesti�n Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

namespace Presentacion
{
    public class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Presentaci�n.Ventana_Principal());
        }
    }
}