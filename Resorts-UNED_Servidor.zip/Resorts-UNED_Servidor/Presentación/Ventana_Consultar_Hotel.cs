﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

using Presentación;
using Entidades;
using LogicaNegocio;

/*Esta ventana despliega la lista de Hoteles creados. Esta ventana
 solo contiene la lógica para regresar al menú principal.*/

namespace Presentacion
{
    public partial class Ventana_Consultar_Hotel : Form
    {
        public Ventana_Consultar_Hotel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Ventana_Principal MenuPrincipal = new Ventana_Principal();
            MenuPrincipal.Show();
        }

        private void Ventana_Consultar_Hotel_Load(object sender, EventArgs e)
        {
            RegistrarHotel RegistroHoteles = new RegistrarHotel();
            dgvConsultarHotel.DataSource = null;
            dgvConsultarHotel.Rows.Clear();
            dgvConsultarHotel.Columns.Clear();

            DataGridViewColumn nuevacolumna = new DataGridViewColumn();
            DataGridViewCell nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "ID Hotel";
            nuevacolumna.Name = "IDHotel";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarHotel.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Nombre";
            nuevacolumna.Name = "NombreHotel";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarHotel.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Dirección";
            nuevacolumna.Name = "DireccionHotel";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarHotel.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Estado";
            nuevacolumna.Name = "EstadoHotel";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarHotel.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Teléfono";
            nuevacolumna.Name = "TelefonoHotel";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarHotel.Columns.Add(nuevacolumna);

            Hotel[] Hoteles = RegistroHoteles.Consultar();

            if (Hoteles != null && Hoteles.Count() > 0)
            {
                foreach (var hotel in Hoteles)
                {
                    if (hotel != null)
                    {
                        DataGridViewRow row = (DataGridViewRow)dgvConsultarHotel.Rows[0].Clone();
                        row.Cells[0].Value = hotel.IDHotel;
                        row.Cells[1].Value = hotel.NombreHotel;
                        row.Cells[2].Value = hotel.DireccionHotel;
                        if (hotel.StatusHotel)
                        {
                            row.Cells[3].Value = "Activo";
                        }
                        else
                        {
                            row.Cells[3].Value = "Inactivo";
                        }
                        row.Cells[4].Value = hotel.TelefonoHotel;
                        dgvConsultarHotel.Rows.Add(row);
                    }
                }
            }
        }
    }
}
