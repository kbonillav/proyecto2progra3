﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/* Este archivo contiene la clase Hotel. Los atributos se declaran
 * privados para cumplir con los principios de encapsulamiento y abstracción
 * que son fundamentales en la POO. Asimismo, se crean los métodos set y get
 * para modificar y accesar a los atributos. Finalmente, se crea un constructor
 * al cual se le pasan los atributos como parámetros, y los guarda en el clase, según
 * el objeto que se haya creado.
 */
namespace Entidades
{
    public class Hotel
        {
        // Atributos privados de la clase Hotel
        private int IDHotel_privado;
        private string NombreHotel_privado;
        private string DireccionHotel_privado;
        private bool StatusHotel_privado;
        private string TelefonoHotel_privado;

        // Métodos set y get para fijar los valores de los atributos
        public int IDHotel
            {
                get { return IDHotel_privado; }
                set { IDHotel_privado = value; }
            }

            public string NombreHotel
            {
                get { return NombreHotel_privado; }
                set { NombreHotel_privado = value; }
            }

            public string DireccionHotel
            {
                get { return DireccionHotel_privado; }
                set { DireccionHotel_privado = value; }
            }

            public bool StatusHotel
            {
                get { return StatusHotel_privado; }
                set { StatusHotel_privado = value; }
            }

            public string TelefonoHotel
            {
                get { return TelefonoHotel_privado; }
                set { TelefonoHotel_privado = value; }
            }

        public Hotel() {}
    }
}
