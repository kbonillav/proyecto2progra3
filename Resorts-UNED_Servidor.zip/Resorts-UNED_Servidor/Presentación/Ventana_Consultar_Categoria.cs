﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 2: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 7 de abril de 2024
 */


/*Al igual que la ventana de consultar hotel esta ventana
 muestra las categorías creadas. Solo se implementa la lógica
para regresar al menú principal.*/
using Entidades;
using LogicaNegocio;
using Presentación;

namespace Presentacion
{
    public partial class Ventana_Consultar_Categoria : Form
    {
        public Ventana_Consultar_Categoria()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Ventana_Principal MenuPrincipal = new Ventana_Principal();
            MenuPrincipal.Show();
        }

        private void Ventana_Consultar_Categoria_Load(object sender, EventArgs e)
        {
            RegistrarCategoriaArticulo CategoriaArticulo = new RegistrarCategoriaArticulo();
            dgvCategorias.DataSource = null;
            dgvCategorias.Rows.Clear();
            dgvCategorias.Columns.Clear();

            DataGridViewColumn nuevacolumna = new DataGridViewColumn();
            DataGridViewCell nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "ID Categoría";
            nuevacolumna.Name = "IDCategoria";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvCategorias.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Descripción";
            nuevacolumna.Name = "DescripcionCategoria";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvCategorias.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Estado";
            nuevacolumna.Name = "EstadoCategoria";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvCategorias.Columns.Add(nuevacolumna);

            Categoria_Articulo[] CategoriasArticulos = CategoriaArticulo.Consultar();

            if(CategoriasArticulos != null && CategoriasArticulos.Count() > 0)
            {
                foreach(var categoria in CategoriasArticulos)
                {
                    if(categoria != null)
                    {
                        DataGridViewRow row = (DataGridViewRow)dgvCategorias.Rows[0].Clone();
                        row.Cells[0].Value = categoria.IDCategoria;
                        row.Cells[1].Value = categoria.DescripcionCategoria;
                        if (categoria.StatusCategoria) 
                        {
                            row.Cells[2].Value = "Activa";
                        }
                        else 
                        {
                            row.Cells[2].Value = "Inactiva";
                        }
                        dgvCategorias.Rows.Add(row);
                    }
                }
            }
        }
    }
}
