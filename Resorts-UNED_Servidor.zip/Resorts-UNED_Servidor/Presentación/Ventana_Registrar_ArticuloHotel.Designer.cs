﻿namespace Presentacion
{
    partial class Ventana_Registrar_ArticuloHotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            IDHotel_seleccionado = new ComboBox();
            hotelBindingSource = new BindingSource(components);
            label2 = new Label();
            NombreHotel_seleccionado = new TextBox();
            DireccionHotel_seleccionado = new TextBox();
            label3 = new Label();
            dataGridView1 = new DataGridView();
            iDCategoriaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            descripcionCategoriaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            statusCategoriaDataGridViewCheckBoxColumn = new DataGridViewCheckBoxColumn();
            categoriaArticuloBindingSource = new BindingSource(components);
            DatosArticulos = new DataGridView();
            iDArticuloDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            nombreArticuloDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            precioArticuloDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            categoriaArticuloDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            articuloBindingSource = new BindingSource(components);
            button1 = new Button();
            button2 = new Button();
            label4 = new Label();
            entrada1_ArticuloHotel = new TextBox();
            label5 = new Label();
            entrada2_ArticuloHotel = new TextBox();
            button3 = new Button();
            ((System.ComponentModel.ISupportInitialize)hotelBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)categoriaArticuloBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DatosArticulos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)articuloBindingSource).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 41);
            label1.Name = "label1";
            label1.Size = new Size(143, 15);
            label1.TabIndex = 0;
            label1.Text = "Seleccione el ID del Hotel:";
            // 
            // IDHotel_seleccionado
            // 
            IDHotel_seleccionado.DataSource = hotelBindingSource;
            IDHotel_seleccionado.DisplayMember = "IDHotel";
            IDHotel_seleccionado.FormattingEnabled = true;
            IDHotel_seleccionado.Location = new Point(190, 38);
            IDHotel_seleccionado.Name = "IDHotel_seleccionado";
            IDHotel_seleccionado.Size = new Size(259, 23);
            IDHotel_seleccionado.TabIndex = 1;
            // 
            // hotelBindingSource
            // 
            hotelBindingSource.DataSource = typeof(Entidades.Hotel);
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 99);
            label2.Name = "label2";
            label2.Size = new Size(81, 15);
            label2.TabIndex = 2;
            label2.Text = "Nombre hotel";
            // 
            // NombreHotel_seleccionado
            // 
            NombreHotel_seleccionado.Location = new Point(190, 96);
            NombreHotel_seleccionado.Name = "NombreHotel_seleccionado";
            NombreHotel_seleccionado.Size = new Size(259, 23);
            NombreHotel_seleccionado.TabIndex = 3;
            // 
            // DireccionHotel_seleccionado
            // 
            DireccionHotel_seleccionado.Location = new Point(190, 153);
            DireccionHotel_seleccionado.Name = "DireccionHotel_seleccionado";
            DireccionHotel_seleccionado.Size = new Size(259, 23);
            DireccionHotel_seleccionado.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 156);
            label3.Name = "label3";
            label3.Size = new Size(87, 15);
            label3.TabIndex = 5;
            label3.Text = "Dirección hotel";
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { iDCategoriaDataGridViewTextBoxColumn, descripcionCategoriaDataGridViewTextBoxColumn, statusCategoriaDataGridViewCheckBoxColumn });
            dataGridView1.DataSource = categoriaArticuloBindingSource;
            dataGridView1.Location = new Point(22, 193);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(382, 119);
            dataGridView1.TabIndex = 6;
            // 
            // iDCategoriaDataGridViewTextBoxColumn
            // 
            iDCategoriaDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            iDCategoriaDataGridViewTextBoxColumn.DataPropertyName = "IDCategoria";
            iDCategoriaDataGridViewTextBoxColumn.HeaderText = "IDCategoria";
            iDCategoriaDataGridViewTextBoxColumn.Name = "iDCategoriaDataGridViewTextBoxColumn";
            iDCategoriaDataGridViewTextBoxColumn.Width = 94;
            // 
            // descripcionCategoriaDataGridViewTextBoxColumn
            // 
            descripcionCategoriaDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            descripcionCategoriaDataGridViewTextBoxColumn.DataPropertyName = "DescripcionCategoria";
            descripcionCategoriaDataGridViewTextBoxColumn.HeaderText = "DescripcionCategoria";
            descripcionCategoriaDataGridViewTextBoxColumn.Name = "descripcionCategoriaDataGridViewTextBoxColumn";
            descripcionCategoriaDataGridViewTextBoxColumn.Width = 145;
            // 
            // statusCategoriaDataGridViewCheckBoxColumn
            // 
            statusCategoriaDataGridViewCheckBoxColumn.DataPropertyName = "StatusCategoria";
            statusCategoriaDataGridViewCheckBoxColumn.HeaderText = "StatusCategoria";
            statusCategoriaDataGridViewCheckBoxColumn.Name = "statusCategoriaDataGridViewCheckBoxColumn";
            // 
            // categoriaArticuloBindingSource
            // 
            categoriaArticuloBindingSource.DataSource = typeof(Entidades.Categoria_Articulo);
            // 
            // DatosArticulos
            // 
            DatosArticulos.AutoGenerateColumns = false;
            DatosArticulos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DatosArticulos.Columns.AddRange(new DataGridViewColumn[] { iDArticuloDataGridViewTextBoxColumn, nombreArticuloDataGridViewTextBoxColumn, precioArticuloDataGridViewTextBoxColumn, categoriaArticuloDataGridViewTextBoxColumn });
            DatosArticulos.DataSource = articuloBindingSource;
            DatosArticulos.Location = new Point(22, 335);
            DatosArticulos.Name = "DatosArticulos";
            DatosArticulos.Size = new Size(483, 134);
            DatosArticulos.TabIndex = 7;
            DatosArticulos.CellContentClick += dataGridView2_CellContentClick;
            // 
            // iDArticuloDataGridViewTextBoxColumn
            // 
            iDArticuloDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            iDArticuloDataGridViewTextBoxColumn.DataPropertyName = "IDArticulo";
            iDArticuloDataGridViewTextBoxColumn.HeaderText = "IDArticulo";
            iDArticuloDataGridViewTextBoxColumn.Name = "iDArticuloDataGridViewTextBoxColumn";
            iDArticuloDataGridViewTextBoxColumn.Width = 85;
            // 
            // nombreArticuloDataGridViewTextBoxColumn
            // 
            nombreArticuloDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            nombreArticuloDataGridViewTextBoxColumn.DataPropertyName = "NombreArticulo";
            nombreArticuloDataGridViewTextBoxColumn.HeaderText = "NombreArticulo";
            nombreArticuloDataGridViewTextBoxColumn.Name = "nombreArticuloDataGridViewTextBoxColumn";
            nombreArticuloDataGridViewTextBoxColumn.Width = 118;
            // 
            // precioArticuloDataGridViewTextBoxColumn
            // 
            precioArticuloDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            precioArticuloDataGridViewTextBoxColumn.DataPropertyName = "PrecioArticulo";
            precioArticuloDataGridViewTextBoxColumn.HeaderText = "PrecioArticulo";
            precioArticuloDataGridViewTextBoxColumn.Name = "precioArticuloDataGridViewTextBoxColumn";
            precioArticuloDataGridViewTextBoxColumn.Width = 107;
            // 
            // categoriaArticuloDataGridViewTextBoxColumn
            // 
            categoriaArticuloDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            categoriaArticuloDataGridViewTextBoxColumn.DataPropertyName = "Categoria_Articulo";
            categoriaArticuloDataGridViewTextBoxColumn.HeaderText = "Categoria_Articulo";
            categoriaArticuloDataGridViewTextBoxColumn.Name = "categoriaArticuloDataGridViewTextBoxColumn";
            categoriaArticuloDataGridViewTextBoxColumn.Width = 130;
            // 
            // articuloBindingSource
            // 
            articuloBindingSource.DataSource = typeof(Entidades.Articulo);
            // 
            // button1
            // 
            button1.Location = new Point(24, 589);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 8;
            button1.Text = "Registrar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(432, 589);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 9;
            button2.Text = "Volver";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(35, 493);
            label4.Name = "label4";
            label4.Size = new Size(78, 15);
            label4.TabIndex = 10;
            label4.Text = "ID asignación";
            // 
            // entrada1_ArticuloHotel
            // 
            entrada1_ArticuloHotel.Location = new Point(211, 490);
            entrada1_ArticuloHotel.Name = "entrada1_ArticuloHotel";
            entrada1_ArticuloHotel.Size = new Size(294, 23);
            entrada1_ArticuloHotel.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(35, 547);
            label5.Name = "label5";
            label5.Size = new Size(170, 15);
            label5.TabIndex = 12;
            label5.Text = "Ingrese la fecha (aaaa-mm-dd)";
            // 
            // entrada2_ArticuloHotel
            // 
            entrada2_ArticuloHotel.Location = new Point(211, 544);
            entrada2_ArticuloHotel.Name = "entrada2_ArticuloHotel";
            entrada2_ArticuloHotel.Size = new Size(294, 23);
            entrada2_ArticuloHotel.TabIndex = 13;
            // 
            // button3
            // 
            button3.Location = new Point(226, 589);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 14;
            button3.Text = "Limpiar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Ventana_Registrar_ArticuloHotel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(525, 624);
            Controls.Add(button3);
            Controls.Add(entrada2_ArticuloHotel);
            Controls.Add(label5);
            Controls.Add(entrada1_ArticuloHotel);
            Controls.Add(label4);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(DatosArticulos);
            Controls.Add(dataGridView1);
            Controls.Add(label3);
            Controls.Add(DireccionHotel_seleccionado);
            Controls.Add(NombreHotel_seleccionado);
            Controls.Add(label2);
            Controls.Add(IDHotel_seleccionado);
            Controls.Add(label1);
            Name = "Ventana_Registrar_ArticuloHotel";
            Text = "Ventana_Registrar_ArticuloHotel";
            ((System.ComponentModel.ISupportInitialize)hotelBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)categoriaArticuloBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)DatosArticulos).EndInit();
            ((System.ComponentModel.ISupportInitialize)articuloBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ComboBox IDHotel_seleccionado;
        private Label label2;
        private TextBox NombreHotel_seleccionado;
        private TextBox DireccionHotel_seleccionado;
        private Label label3;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn iDCategoriaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn descripcionCategoriaDataGridViewTextBoxColumn;
        private DataGridViewCheckBoxColumn statusCategoriaDataGridViewCheckBoxColumn;
        private BindingSource categoriaArticuloBindingSource;
        private DataGridView DatosArticulos;
        private DataGridViewTextBoxColumn iDArticuloDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn nombreArticuloDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn precioArticuloDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn categoriaArticuloDataGridViewTextBoxColumn;
        private BindingSource articuloBindingSource;
        private Button button1;
        private Button button2;
        private BindingSource hotelBindingSource;
        private Label label4;
        private TextBox entrada1_ArticuloHotel;
        private Label label5;
        private TextBox entrada2_ArticuloHotel;
        private Button button3;
    }
}