﻿namespace Presentacion
{
    partial class Ventana_Consultar_Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            clienteBindingSource = new BindingSource(components);
            iDClienteDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            nombreClienteDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            primerApellidoDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            segundoApellidoDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            fechaNacimientoDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            generoDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)clienteBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { iDClienteDataGridViewTextBoxColumn, nombreClienteDataGridViewTextBoxColumn, primerApellidoDataGridViewTextBoxColumn, segundoApellidoDataGridViewTextBoxColumn, fechaNacimientoDataGridViewTextBoxColumn, generoDataGridViewTextBoxColumn });
            dataGridView1.DataSource = clienteBindingSource;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(665, 329);
            dataGridView1.TabIndex = 0;
            // 
            // clienteBindingSource
            // 
            clienteBindingSource.DataSource = typeof(Entidades.Cliente);
            // 
            // iDClienteDataGridViewTextBoxColumn
            // 
            iDClienteDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            iDClienteDataGridViewTextBoxColumn.DataPropertyName = "IDCliente";
            iDClienteDataGridViewTextBoxColumn.HeaderText = "IDCliente";
            iDClienteDataGridViewTextBoxColumn.Name = "iDClienteDataGridViewTextBoxColumn";
            iDClienteDataGridViewTextBoxColumn.ReadOnly = true;
            iDClienteDataGridViewTextBoxColumn.Width = 80;
            // 
            // nombreClienteDataGridViewTextBoxColumn
            // 
            nombreClienteDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            nombreClienteDataGridViewTextBoxColumn.DataPropertyName = "NombreCliente";
            nombreClienteDataGridViewTextBoxColumn.HeaderText = "NombreCliente";
            nombreClienteDataGridViewTextBoxColumn.Name = "nombreClienteDataGridViewTextBoxColumn";
            nombreClienteDataGridViewTextBoxColumn.ReadOnly = true;
            nombreClienteDataGridViewTextBoxColumn.Width = 113;
            // 
            // primerApellidoDataGridViewTextBoxColumn
            // 
            primerApellidoDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            primerApellidoDataGridViewTextBoxColumn.DataPropertyName = "PrimerApellido";
            primerApellidoDataGridViewTextBoxColumn.HeaderText = "PrimerApellido";
            primerApellidoDataGridViewTextBoxColumn.Name = "primerApellidoDataGridViewTextBoxColumn";
            primerApellidoDataGridViewTextBoxColumn.ReadOnly = true;
            primerApellidoDataGridViewTextBoxColumn.Width = 111;
            // 
            // segundoApellidoDataGridViewTextBoxColumn
            // 
            segundoApellidoDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            segundoApellidoDataGridViewTextBoxColumn.DataPropertyName = "SegundoApellido";
            segundoApellidoDataGridViewTextBoxColumn.HeaderText = "SegundoApellido";
            segundoApellidoDataGridViewTextBoxColumn.Name = "segundoApellidoDataGridViewTextBoxColumn";
            segundoApellidoDataGridViewTextBoxColumn.ReadOnly = true;
            segundoApellidoDataGridViewTextBoxColumn.Width = 123;
            // 
            // fechaNacimientoDataGridViewTextBoxColumn
            // 
            fechaNacimientoDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            fechaNacimientoDataGridViewTextBoxColumn.DataPropertyName = "FechaNacimiento";
            fechaNacimientoDataGridViewTextBoxColumn.HeaderText = "FechaNacimiento";
            fechaNacimientoDataGridViewTextBoxColumn.Name = "fechaNacimientoDataGridViewTextBoxColumn";
            fechaNacimientoDataGridViewTextBoxColumn.ReadOnly = true;
            fechaNacimientoDataGridViewTextBoxColumn.Width = 125;
            // 
            // generoDataGridViewTextBoxColumn
            // 
            generoDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            generoDataGridViewTextBoxColumn.DataPropertyName = "Genero";
            generoDataGridViewTextBoxColumn.HeaderText = "Genero";
            generoDataGridViewTextBoxColumn.Name = "generoDataGridViewTextBoxColumn";
            generoDataGridViewTextBoxColumn.ReadOnly = true;
            generoDataGridViewTextBoxColumn.Width = 70;
            // 
            // button1
            // 
            button1.Location = new Point(604, 347);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Ventana_Consultar_Clientes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 379);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Name = "Ventana_Consultar_Clientes";
            Text = "Ventana_Consultar_Clientes";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)clienteBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn iDClienteDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn nombreClienteDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn primerApellidoDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn segundoApellidoDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn fechaNacimientoDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn generoDataGridViewTextBoxColumn;
        private BindingSource clienteBindingSource;
        private Button button1;
    }
}