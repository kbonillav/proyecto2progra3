﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/*La clase Cliente, al igual que las anteriores,
 contiene los atributos, métodos set y get y constructor.*/

using System.Reflection;

namespace Entidades
{
    public class Cliente
    {
        // Atributos privados
        private string IDCliente_privado;
        private string NombreCliente_privado;
        private string PrimerApellido_privado;
        private string SegundoApellido_privado;
        private DateTime FechaNacimiento_privado;
        private char Genero_privado;

        // Métodos set y get para los atributos
        public string IDCliente
        {
            get { return IDCliente_privado; }
            set { IDCliente_privado = value; }
        }

        public string NombreCliente
        {
            get { return NombreCliente_privado; }
            set { NombreCliente_privado = value; }
        }

        public string PrimerApellido
        {
            get { return PrimerApellido_privado; }
            set { PrimerApellido_privado = value; }
        }

        public string SegundoApellido
        {
            get { return SegundoApellido_privado; }
            set { SegundoApellido_privado = value; }
        }

        public DateTime FechaNacimiento
        {
            get { return FechaNacimiento_privado; }
            set { FechaNacimiento_privado = value; }
        }

        public char Genero
        {
            get { return Genero_privado; }
            set { Genero_privado = value; }
        }

        // Constructor con los parámetros
        public Cliente(string IDCliente, string NombreCliente, string PrimerApellido, string SegundoApellido, DateTime FechaNacimiento, char Genero)
        {
            IDCliente = IDCliente;
            NombreCliente = NombreCliente;
            PrimerApellido = PrimerApellido;
            SegundoApellido = SegundoApellido;
            FechaNacimiento = FechaNacimiento;
            Genero = Genero;
        }
    }
}
