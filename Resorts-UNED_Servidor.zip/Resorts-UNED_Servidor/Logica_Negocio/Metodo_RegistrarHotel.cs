﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

namespace Logica_Negocio
{
    public class Metodo_RegistrarHotel
    {
        public void RegistrarHotel()
        {

            Hotel[] hoteles = new Hotel[20];
            int indicehotel = 0;
            do
            {
                int IDHotel_ingresado = 0;
                try
                {
                    IDHotel_ingresado = int.Parse(Entrada1.Text);
                    do
                    {
                        Console.WriteLine("ID de hotel repetido. Ingrese uno nuevo");
                        IDHotel_ingresado = int.Parse(Entrada1.Text);
                    }
                    while (hoteles.Any(h => h != null && h.IDHotel == IDHotel_ingresado));
                }
                catch (FormatException)
                {
                    Console.WriteLine("Entrada inválida. Por favor ingrese un ID válido");
                    IDHotel_ingresado = int.Parse(Console.ReadLine());
                }
                string NombreHotel_ingresado = Entrada2.Text;

                string DireccionHotel_ingresada = Entrada3.Text;

                string status_ingresado = Opcion1.GetItemText(Opcion1.SelectedItem);

                bool seleccion;
                if (status_ingresado.Equals("Activo"))
                {
                    seleccion = true;
                }
                else
                {
                    seleccion = false;
                }

                string TelefonoHotel_ingresado = Entrada4.Text;

                hoteles[indicehotel] = new Hotel(IDHotel_ingresado, NombreHotel_ingresado, DireccionHotel_ingresada, seleccion, TelefonoHotel_ingresado);

                Console.WriteLine("Hotel creado: {0}", hoteles[indicehotel]);

                indicehotel++;
            }
            while (MessageBox.Show("Resultado", "Desea agregar otro hotel?", MessageBoxButtons.YesNo) == DialogResult.Yes && indicehotel < hoteles.Length);
        }
    }
}