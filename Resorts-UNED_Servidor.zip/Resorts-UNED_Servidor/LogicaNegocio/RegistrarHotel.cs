﻿using AccesoDatos;
using Entidades;
using System.Security.Cryptography.X509Certificates;

namespace LogicaNegocio
{
    public class RegistrarHotel
    {
        public bool guardarHotel(Hotel hotel)
        {
            bool hotelregistrado = false;

            Hotel[] Hoteles = HotelAD.ConsultarHoteles();

            for (int i = 0; i < Hoteles.Length; i++) {
                if (Hoteles[i] != null && Hoteles[i].IDHotel == hotel.IDHotel)
                {
                    hotelregistrado = true;
                    break;
                }
            }
            if (hotelregistrado)
            {
                return false;
            }
            else
            {
                return HotelAD.Registrarhotel(hotel);
            }
        }
        public Hotel[] Consultar()
        {
            return HotelAD.ConsultarHoteles();
        }
    }
}
