﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

using Entidades;
using Presentación;
using System.Globalization;

/*Esta ventana, de la capa GUI es la que se encarga de
 registrar los artículos en algún hotel previamente registrado.
Primero se lee el ID de Hotel del desplegable, y con base en esto
se autocompleta el nombre y la direccion. Luego carga las categorías
de articulos disponibles y con base en la categoría carga los artículos
asociados. Luego se escogen los artículos, se indica el ID de la asignación
y la fecha y se guarda el registro. Finalmente, el sistema le pregunta
al usuario si desea ingresar otra asignación. El botón limpiar borra los campos
de texto y el de volver regresa al menú principal.*/

namespace Presentacion
{
    public partial class Ventana_Registrar_ArticuloHotel : Form
    {
        public Ventana_Registrar_ArticuloHotel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ArticuloHotel[] ArticulosHotel = new ArticuloHotel[20];
            int indicearticulohotel = 0;
            int IDasignacion_ingresado = 0;

            do
            {
                try
                {
                    IDasignacion_ingresado = int.Parse(entrada1_ArticuloHotel.Text);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("ID de asignación inválido. Intente nuevamente: ");
                    IDasignacion_ingresado = int.Parse(Console.ReadLine());
                }

                DateTime FechaAsignacion = DateTime.ParseExact(entrada2_ArticuloHotel.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None);

                string temp = IDHotel_seleccionado.GetItemText(IDHotel_seleccionado.SelectedItem);
                int IDHotel = int.Parse(temp);

                Hotel[] HotelSeleccionado = new Hotel[20];
                int contador = 0;

                try
                {
                    for (int i = 0; i < HotelSeleccionado.Length; i++)
                    {
                        do
                        {
                            if (HotelSeleccionado[i].IDHotel == IDHotel && HotelSeleccionado[i].StatusHotel == true)
                            { 
                                NombreHotel_seleccionado.Text = HotelSeleccionado[i].NombreHotel;
                                DireccionHotel_seleccionado.Text = HotelSeleccionado[i].DireccionHotel;
                                contador = i;
                                break;
                            }
                        }
                        while (HotelSeleccionado != null);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error buscando ID de Hotel. Regresando al Menú Principal");
                    this.Close();
                    Ventana_Principal MenuPrincipal = new Ventana_Principal();
                    MenuPrincipal.Show();

                }

                Articulo[] ArticulosAsignados = new Articulo[10];

                //Código faltante para asignar objetos de la clase Articulo

                ArticulosHotel[indicearticulohotel] = new ArticuloHotel(IDasignacion_ingresado, FechaAsignacion, HotelSeleccionado[contador], ArticulosAsignados);

                // Muestra el objeto creado en consola.
                Console.WriteLine("Artículos asignados al hotel correctamente: {0}", ArticulosHotel[indicearticulohotel]);

                indicearticulohotel++;

            }
            while (MessageBox.Show("Resultado", "Desea realizar otra asignación?", MessageBoxButtons.YesNo) == DialogResult.Yes && indicearticulohotel < ArticulosHotel.Length);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Ventana_Principal MenuPrincipal = new Ventana_Principal();
            MenuPrincipal.Show();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            entrada1_ArticuloHotel.Text = String.Empty;
            entrada2_ArticuloHotel.Text = String.Empty;
            NombreHotel_seleccionado.Text = String.Empty;
            DireccionHotel_seleccionado.Text= String.Empty;
        }
    }
}
