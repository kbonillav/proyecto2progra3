﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/*Esta interfaz es la ventana del Menú Principal. Aquí solo se
 implementan los botones que llevan a las otras ventanas implementadas
para cada método. Se implementa un botón que termina la aplicación.*/

using Presentacion;

namespace Presentación
{
    public partial class Ventana_Principal : Form
    {
        public Ventana_Principal()
        {
            InitializeComponent();
        }

        private void Btn_Registrar_Hotel_Click(object sender, EventArgs e)
        {
            Ventana_Registrar_Hotel NuevoHotel = new Ventana_Registrar_Hotel();
            NuevoHotel.ShowDialog();
            this.Close();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Registrar_Cliente NuevoCliente = new Presentacion.Ventana_Registrar_Cliente();
            NuevoCliente.ShowDialog();
            this.Close();
        }

        private void btn_registrar_articulo_hotel_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Registrar_ArticuloHotel NuevoArticuloHotel = new Presentacion.Ventana_Registrar_ArticuloHotel();
            NuevoArticuloHotel.ShowDialog();
            this.Close();
        }

        private void btn_registrar_categoria_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Registrar_Categoria_Articulo NuevaCategoria = new Ventana_Registrar_Categoria_Articulo();
            NuevaCategoria.ShowDialog();
            this.Close();
        }

        private void btn_registrar_articulo_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Registrar_Articulo NuevoArticulo = new Ventana_Registrar_Articulo();
            NuevoArticulo.ShowDialog();
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Consultar_Hotel RevisarHoteles = new Ventana_Consultar_Hotel();
            RevisarHoteles.ShowDialog();
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Consultar_Categoria RevisarCategorias = new Ventana_Consultar_Categoria();
            RevisarCategorias.ShowDialog();
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Consultar_Articulo RevisarArticulos = new Ventana_Consultar_Articulo();
            RevisarArticulos.ShowDialog();
            this.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Consultar_Clientes RevisarClientes = new Ventana_Consultar_Clientes();
            RevisarClientes.ShowDialog();
            this.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Presentacion.Ventana_Consultar_ArticuloHotel RevisarArticulosHotel = new Ventana_Consultar_ArticuloHotel();
            RevisarArticulosHotel.ShowDialog();
            this.Close();
        }
    }
}
