﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/*Esta ventana implementa el método para Registrar Artículos.
 También se pone la lógica para limpiar los espacios de texto
y volver al menú principal*/

using Entidades;
using LogicaNegocio;
using Presentación;

namespace Presentacion
{
    public partial class Ventana_Registrar_Articulo : Form
    {
        public Ventana_Registrar_Articulo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string articulovalido = ValidacionDatosArticulo();

                if (string.IsNullOrWhiteSpace(articulovalido)) 
                {
                    Articulo NuevoArticulo = new Articulo();
                    NuevoArticulo.IDArticulo = int.Parse(entrada1_articulo.Text);
                    NuevoArticulo.NombreArticulo = entrada2_articulo.Text;
                    NuevoArticulo.PrecioArticulo = int.Parse(entrada3_articulo.Text);

                    int CategoriaArticuloAsignada = int.Parse(entrada4_articulo.Text);

                    try
                    {
                        RegistrarCategoriaArticulo Categorias_Disponibles = new RegistrarCategoriaArticulo();
                        Categoria_Articulo[] RegistroCategorias = Categorias_Disponibles.Consultar();
                        for (int i = 0; i < RegistroCategorias.Length; i++)
                        {
                            if (RegistroCategorias[i].IDCategoria == CategoriaArticuloAsignada)
                            {
                                NuevoArticulo.Categoria_Articulo = RegistroCategorias[i];
                                break;
                            }
                            else
                            {
                                MessageBox.Show("La ID de la categoría es inválida");
                            }
                        }
                    }
                    catch (NullReferenceException)
                    {
                        MessageBox.Show("No se ha registrado ninguna categoría. Favor registrar alguna antes");
                        this.Close();
                    }

                    RegistrarArticulos registrarArticulos = new RegistrarArticulos();
                    bool RegistroCorrecto = registrarArticulos.GuardarArticulo(NuevoArticulo);

                    if (RegistroCorrecto)
                    {
                        MessageBox.Show("Artículo registrado correctamente");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo registrar el artículo");
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Ha ocurrido un error, el formato no es el correcto");
            }
            catch (OverflowException)
            {
                MessageBox.Show("El número ingresado no es válido porque es muy grande");
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                //Aunque se podría mostrar el mensaje (ex.Message) de error no es una buena práctica ya que el usuario no 
                //entendería un mensaje técnico, normalmente se utiliza para bitácoras, etc.
                //MessageBox.Show("Ha ocurrido un error " + ex.Message);

                MessageBox.Show("Ha ocurrido un error contacte  al administrador");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            entrada1_articulo.Text = String.Empty;
            entrada2_articulo.Text = String.Empty;
            entrada3_articulo.Text = String.Empty;
            entrada4_articulo.Text = String.Empty;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Ventana_Principal MenuPrincipal = new Ventana_Principal();
            MenuPrincipal.Show();
        }

        private string ValidacionDatosArticulo() 
        { 
            string validacion = string.Empty;

            if (string.IsNullOrWhiteSpace(entrada1_articulo.Text))
            {
                entrada1_articulo.Focus();
                return "Debe ingresar la ID del artículo";
            }
            else if (string.IsNullOrWhiteSpace(entrada2_articulo.Text))
            {
                entrada2_articulo.Focus();
                return "Debe ingresar el nombre del artículo";
            }
            else if (string.IsNullOrWhiteSpace(entrada3_articulo.Text))
            {
                entrada3_articulo.Focus();
                return "Debe ingresar el precio del artículo";
            }
            else if (string.IsNullOrWhiteSpace(entrada4_articulo.Text))
            {
                entrada4_articulo.Focus();
                return "Debe indicar la ID de la categoría para el artículo";
            }

            return validacion;
        }
    }
}
