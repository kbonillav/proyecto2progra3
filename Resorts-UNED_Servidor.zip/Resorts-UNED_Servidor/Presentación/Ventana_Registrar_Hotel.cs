﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/*Esta ventana primero requiere llamar a la biblioteca de Entidades.
 Esta ventana implementa el método para registrar los objetos de
la clase Hotel. Se supone que esto debía estar en la capa de lógica
de negocios, pero no se pudo completar este requisito. Se implementa la
lógica para limpiar los espacios de texto y regresar al menú principal*/

using Entidades;
using LogicaNegocio;
using System.Drawing.Text;

namespace Presentación
{
    public partial class Ventana_Registrar_Hotel : Form
    {
        public Ventana_Registrar_Hotel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string validacion = ValidacionDatosHotel();

                if (string.IsNullOrWhiteSpace(validacion))
                {
                    Hotel NuevoHotel = new Hotel();
                    NuevoHotel.IDHotel = int.Parse(Entrada1.Text);
                    NuevoHotel.NombreHotel = Entrada2.Text;
                    NuevoHotel.DireccionHotel = Entrada3.Text;
                    string status_ingresado = Opcion1.GetItemText(Opcion1.SelectedItem);
                    bool seleccion;
                    if (status_ingresado.Equals("Activo"))
                    {
                        seleccion = true;
                    }
                    else
                    {
                        seleccion = false;
                    }
                    NuevoHotel.StatusHotel = seleccion;
                    NuevoHotel.TelefonoHotel = Entrada4.Text;

                    RegistrarHotel registrohotel = new RegistrarHotel();
                    bool registrocorrecto = registrohotel.guardarHotel(NuevoHotel);

                    if (registrocorrecto)
                    {
                        MessageBox.Show("Hotel guardado");
                    }
                    else {
                        MessageBox.Show("No se pudo guardar el hotel");
                    }
                }
                else
                {
                    MessageBox.Show(validacion);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Ha ocurrido un error, el formato no es el correcto");
            }
            catch (OverflowException)
            {
                MessageBox.Show("El número ingresado no es válido porque es muy grande");
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                //Aunque se podría mostrar el mensaje (ex.Message) de error no es una buena práctica ya que el usuario no 
                //entendería un mensaje técnico, normalmente se utiliza para bitácoras, etc.
                //MessageBox.Show("Ha ocurrido un error " + ex.Message);

                MessageBox.Show("Ha ocurrido un error contacte  al administrador");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Ventana_Principal MenuPrincipal = new Ventana_Principal();
            MenuPrincipal.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Entrada1.Text = String.Empty;
            Entrada2.Text = String.Empty;
            Entrada3.Text = String.Empty;
            Entrada4.Text = String.Empty;
        }

        private string ValidacionDatosHotel()
        {
            string validacion = string.Empty;

            if (string.IsNullOrWhiteSpace(Entrada2.Text))
            {
                Entrada2.Focus();
                return "Debe agregar el nombre del hotel";
            }
            else if (string.IsNullOrWhiteSpace(Entrada3.Text))
            {
                Entrada3.Focus();
                return "Debe ingresar una dirección de hotel válida";
            }
            else if (Opcion1.SelectedItem == null)
            {
                Opcion1.Focus();
                return "Debe escoger un estado para el hotel";
            }
            else if (string.IsNullOrWhiteSpace(Entrada4.Text)) {
                Entrada4.Focus();
                return "Favor ingrese un número de teléfono para el hotel";
            }

            return validacion;
        }
    }
}
