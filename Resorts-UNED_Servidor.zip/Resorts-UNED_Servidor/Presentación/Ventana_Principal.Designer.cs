﻿namespace Presentación
{
    partial class Ventana_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Btn_Registrar_Hotel = new Button();
            btn_registrar_categoria = new Button();
            btn_registrar_articulo = new Button();
            btn_registrar_cliente = new Button();
            btn_registrar_articulo_hotel = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            btn_ventana_principal_salir = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 20);
            label1.Name = "label1";
            label1.Size = new Size(386, 15);
            label1.TabIndex = 1;
            label1.Text = "Bienvenido al menú principal. Seleccione una de las siguientes opciones";
            // 
            // Btn_Registrar_Hotel
            // 
            Btn_Registrar_Hotel.Location = new Point(32, 82);
            Btn_Registrar_Hotel.Name = "Btn_Registrar_Hotel";
            Btn_Registrar_Hotel.Size = new Size(164, 23);
            Btn_Registrar_Hotel.TabIndex = 2;
            Btn_Registrar_Hotel.Text = "Registrar Hotel";
            Btn_Registrar_Hotel.UseVisualStyleBackColor = true;
            Btn_Registrar_Hotel.Click += Btn_Registrar_Hotel_Click;
            // 
            // btn_registrar_categoria
            // 
            btn_registrar_categoria.Location = new Point(32, 149);
            btn_registrar_categoria.Name = "btn_registrar_categoria";
            btn_registrar_categoria.Size = new Size(164, 23);
            btn_registrar_categoria.TabIndex = 3;
            btn_registrar_categoria.Text = "Registrar Categoría Artículo";
            btn_registrar_categoria.UseVisualStyleBackColor = true;
            btn_registrar_categoria.Click += btn_registrar_categoria_Click;
            // 
            // btn_registrar_articulo
            // 
            btn_registrar_articulo.Location = new Point(32, 218);
            btn_registrar_articulo.Name = "btn_registrar_articulo";
            btn_registrar_articulo.Size = new Size(164, 23);
            btn_registrar_articulo.TabIndex = 4;
            btn_registrar_articulo.Text = "Registrar Artículos";
            btn_registrar_articulo.UseVisualStyleBackColor = true;
            btn_registrar_articulo.Click += btn_registrar_articulo_Click;
            // 
            // btn_registrar_cliente
            // 
            btn_registrar_cliente.Location = new Point(32, 284);
            btn_registrar_cliente.Name = "btn_registrar_cliente";
            btn_registrar_cliente.Size = new Size(164, 23);
            btn_registrar_cliente.TabIndex = 5;
            btn_registrar_cliente.Text = "Registrar Clientes";
            btn_registrar_cliente.UseVisualStyleBackColor = true;
            btn_registrar_cliente.Click += button4_Click;
            // 
            // btn_registrar_articulo_hotel
            // 
            btn_registrar_articulo_hotel.Location = new Point(32, 348);
            btn_registrar_articulo_hotel.Name = "btn_registrar_articulo_hotel";
            btn_registrar_articulo_hotel.Size = new Size(164, 23);
            btn_registrar_articulo_hotel.TabIndex = 6;
            btn_registrar_articulo_hotel.Text = "Registrar Artículo por Hotel";
            btn_registrar_articulo_hotel.UseVisualStyleBackColor = true;
            btn_registrar_articulo_hotel.Click += btn_registrar_articulo_hotel_Click;
            // 
            // button6
            // 
            button6.Location = new Point(242, 82);
            button6.Name = "button6";
            button6.Size = new Size(176, 23);
            button6.TabIndex = 7;
            button6.Text = "Consultar Hotel";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(242, 149);
            button7.Name = "button7";
            button7.Size = new Size(176, 23);
            button7.TabIndex = 8;
            button7.Text = "Consultar Categoría Artículo";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(242, 218);
            button8.Name = "button8";
            button8.Size = new Size(176, 23);
            button8.TabIndex = 9;
            button8.Text = "Consultar Artículo";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(242, 284);
            button9.Name = "button9";
            button9.Size = new Size(176, 23);
            button9.TabIndex = 10;
            button9.Text = "Consultar Clientes";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(242, 348);
            button10.Name = "button10";
            button10.Size = new Size(176, 23);
            button10.TabIndex = 11;
            button10.Text = "Consultar Artículos por Hotel";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // btn_ventana_principal_salir
            // 
            btn_ventana_principal_salir.Location = new Point(175, 405);
            btn_ventana_principal_salir.Name = "btn_ventana_principal_salir";
            btn_ventana_principal_salir.Size = new Size(75, 23);
            btn_ventana_principal_salir.TabIndex = 12;
            btn_ventana_principal_salir.Text = "Salir";
            btn_ventana_principal_salir.UseVisualStyleBackColor = true;
            btn_ventana_principal_salir.Click += button11_Click;
            // 
            // Ventana_Principal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(444, 450);
            Controls.Add(btn_ventana_principal_salir);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(btn_registrar_articulo_hotel);
            Controls.Add(btn_registrar_cliente);
            Controls.Add(btn_registrar_articulo);
            Controls.Add(btn_registrar_categoria);
            Controls.Add(Btn_Registrar_Hotel);
            Controls.Add(label1);
            Name = "Ventana_Principal";
            Text = "Ventana_Principal";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button Btn_Registrar_Hotel;
        private Button btn_registrar_categoria;
        private Button btn_registrar_articulo;
        private Button btn_registrar_cliente;
        private Button btn_registrar_articulo_hotel;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button btn_ventana_principal_salir;
    }
}