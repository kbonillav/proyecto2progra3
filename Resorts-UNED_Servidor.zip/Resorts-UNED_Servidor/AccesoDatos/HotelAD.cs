﻿using Entidades;

namespace AccesoDatos
{
    public static class HotelAD
    {
        private static Hotel[] Hoteles = new Hotel[20];
        private static int indicehotel = 0;

        public static bool Registrarhotel(Hotel nuevohotel)
        {
            try
            {
                Hoteles[indicehotel] = nuevohotel;
                indicehotel++;
                return true;
            }
            catch (IndexOutOfRangeException)
            {
                throw new IndexOutOfRangeException("El repositorio esta lleno y no permite registrar más información");
            }
        }

        public static Hotel[] ConsultarHoteles()
        {
            return Hoteles;
        }
    }
}
