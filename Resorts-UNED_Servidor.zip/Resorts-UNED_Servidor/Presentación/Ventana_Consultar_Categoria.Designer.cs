﻿namespace Presentacion
{
    partial class Ventana_Consultar_Categoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dgvCategorias = new DataGridView();
            categoriaArticuloBindingSource = new BindingSource(components);
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvCategorias).BeginInit();
            ((System.ComponentModel.ISupportInitialize)categoriaArticuloBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dgvCategorias
            // 
            dgvCategorias.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCategorias.Location = new Point(12, 12);
            dgvCategorias.Name = "dgvCategorias";
            dgvCategorias.Size = new Size(379, 294);
            dgvCategorias.TabIndex = 0;
            // 
            // categoriaArticuloBindingSource
            // 
            categoriaArticuloBindingSource.DataSource = typeof(Entidades.Categoria_Articulo);
            // 
            // button1
            // 
            button1.Location = new Point(320, 313);
            button1.Name = "button1";
            button1.Size = new Size(71, 27);
            button1.TabIndex = 1;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Ventana_Consultar_Categoria
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(405, 352);
            Controls.Add(button1);
            Controls.Add(dgvCategorias);
            Name = "Ventana_Consultar_Categoria";
            Text = "Ventana_Consultar_Categoria";
            Load += Ventana_Consultar_Categoria_Load;
            ((System.ComponentModel.ISupportInitialize)dgvCategorias).EndInit();
            ((System.ComponentModel.ISupportInitialize)categoriaArticuloBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvCategorias;
        private BindingSource categoriaArticuloBindingSource;
        private Button button1;
    }
}