﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/*Finalmente, se crea la clase ArticuloHotel, la cual
 representa a los objetos de la clase Artículo que se
van a asignar a cada Hotel. Aquí se convocan objetos
de la clase Categoría y Artículo, ya que ambas clases
están relacionadas con esta clase.*/

namespace Entidades
{
    public class ArticuloHotel
    {
        // Atributos privados
        private int IDAsignacion_privado;
        private DateTime Fecha_privado;
        private Hotel Hotel_privado;
        private Articulo[] Articulos_privado = new Articulo[10];

        // Métodos set y get para los atributos
        public int IDAsignacion
        {
            get { return IDAsignacion_privado; }
            set { IDAsignacion_privado = value; }
        }

        public DateTime Fecha
        {
            get { return Fecha_privado; }
            set { Fecha_privado = value; }
        }

        public Hotel Hotel
        {
            get { return Hotel_privado; }
            set { Hotel_privado = value; }
        }

        public Articulo[] Articulos
        {
            get { return Articulos_privado; }
            set { Articulos_privado = value; }
        }

        // Constructor con sus parámetros
        public ArticuloHotel(int IDAsignacion, DateTime Fecha, Hotel Hotel, Articulo[] Articulos)
        {
            IDAsignacion = IDAsignacion;
            Fecha = Fecha;
            Hotel = Hotel;
            Articulos = Articulos;
        }

        //Constructor vacío
        public ArticuloHotel() { }
    }

}
