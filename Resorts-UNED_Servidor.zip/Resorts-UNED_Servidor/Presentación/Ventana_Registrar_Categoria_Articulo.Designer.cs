﻿namespace Presentacion
{
    partial class Ventana_Registrar_Categoria_Articulo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            Entrada_categoria_1 = new TextBox();
            label3 = new Label();
            Entrada_categoria_2 = new TextBox();
            label4 = new Label();
            opcion_categoria_1 = new ComboBox();
            btn_Registrar_Categoria = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(102, 24);
            label1.Name = "label1";
            label1.Size = new Size(267, 15);
            label1.TabIndex = 0;
            label1.Text = "Ingrese la información de la categoría del artículo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(30, 87);
            label2.Name = "label2";
            label2.Size = new Size(154, 15);
            label2.TabIndex = 1;
            label2.Text = "Ingrese el ID de la categoría:";
            // 
            // Entrada_categoria_1
            // 
            Entrada_categoria_1.Location = new Point(211, 84);
            Entrada_categoria_1.Name = "Entrada_categoria_1";
            Entrada_categoria_1.Size = new Size(221, 23);
            Entrada_categoria_1.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(30, 139);
            label3.Name = "label3";
            label3.Size = new Size(152, 15);
            label3.TabIndex = 3;
            label3.Text = "Descripción de la categoría:";
            // 
            // Entrada_categoria_2
            // 
            Entrada_categoria_2.Location = new Point(211, 136);
            Entrada_categoria_2.Name = "Entrada_categoria_2";
            Entrada_categoria_2.Size = new Size(221, 23);
            Entrada_categoria_2.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(30, 193);
            label4.Name = "label4";
            label4.Size = new Size(201, 15);
            label4.TabIndex = 5;
            label4.Text = "Seleccione el estado (activa/inactiva)";
            // 
            // opcion_categoria_1
            // 
            opcion_categoria_1.FormattingEnabled = true;
            opcion_categoria_1.Items.AddRange(new object[] { "Activa", "Inactiva" });
            opcion_categoria_1.Location = new Point(237, 190);
            opcion_categoria_1.Name = "opcion_categoria_1";
            opcion_categoria_1.Size = new Size(195, 23);
            opcion_categoria_1.TabIndex = 6;
            // 
            // btn_Registrar_Categoria
            // 
            btn_Registrar_Categoria.Location = new Point(30, 254);
            btn_Registrar_Categoria.Name = "btn_Registrar_Categoria";
            btn_Registrar_Categoria.Size = new Size(75, 23);
            btn_Registrar_Categoria.TabIndex = 7;
            btn_Registrar_Categoria.Text = "Registrar";
            btn_Registrar_Categoria.UseVisualStyleBackColor = true;
            btn_Registrar_Categoria.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(193, 254);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 8;
            button2.Text = "Limpiar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(357, 254);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 9;
            button3.Text = "Volver";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Ventana_Registrar_Categoria_Articulo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(474, 300);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(btn_Registrar_Categoria);
            Controls.Add(opcion_categoria_1);
            Controls.Add(label4);
            Controls.Add(Entrada_categoria_2);
            Controls.Add(label3);
            Controls.Add(Entrada_categoria_1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Ventana_Registrar_Categoria_Articulo";
            Text = "Ventana_Registrar_Categoria_Articulo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox Entrada_categoria_1;
        private Label label3;
        private TextBox Entrada_categoria_2;
        private Label label4;
        private ComboBox opcion_categoria_1;
        private Button btn_Registrar_Categoria;
        private Button button2;
        private Button button3;
    }
}