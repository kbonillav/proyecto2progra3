﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/*Esta ventana muestra los artículos registrados. El boton
 de esta ventana solo llama al menú principal.*/
using Entidades;
using LogicaNegocio;
using Presentación;

namespace Presentacion
{
    public partial class Ventana_Consultar_Articulo : Form
    {
        public Ventana_Consultar_Articulo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Ventana_Principal MenuPrincipal = new Ventana_Principal();
            MenuPrincipal.Show();
        }

        private void Ventana_Consultar_Articulo_Load(object sender, EventArgs e) 
        {
            RegistrarArticulos ArticulosRegistrados = new RegistrarArticulos();
            dgvConsultarArticulos.DataSource = null;
            dgvConsultarArticulos.Rows.Clear();
            dgvConsultarArticulos.Columns.Clear();

            DataGridViewColumn nuevacolumna = new DataGridViewColumn();
            DataGridViewCell nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "ID Artículo";
            nuevacolumna.Name = "IDArticulo";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarArticulos.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Nombre Artículo";
            nuevacolumna.Name = "NombreArticulo";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarArticulos.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Precio Artículo";
            nuevacolumna.Name = "PrecioArticulo";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarArticulos.Columns.Add(nuevacolumna);

            nuevacolumna = new DataGridViewColumn();
            nuevacelda = new DataGridViewTextBoxCell();

            nuevacolumna.CellTemplate = nuevacelda;
            nuevacolumna.HeaderText = "Categoría Artículo";
            nuevacolumna.Name = "CategoriaArticulo";
            nuevacolumna.Visible = true;
            nuevacolumna.Width = 100;

            dgvConsultarArticulos.Columns.Add(nuevacolumna);

            Articulo[] Articulosregistrados = ArticulosRegistrados.Consultar();

            if(Articulosregistrados != null && Articulosregistrados.Count() > 0)
            {
                foreach (var articulo in Articulosregistrados)
                {
                    if (articulo != null) 
                    {
                        DataGridViewRow row = (DataGridViewRow)dgvConsultarArticulos.Rows[0].Clone();
                        row.Cells[0].Value = articulo.IDArticulo;
                        row.Cells[1].Value = articulo.NombreArticulo;
                        row.Cells[2].Value = articulo.PrecioArticulo;
                        row.Cells[3].Value = articulo.Categoria_Articulo;
                        dgvConsultarArticulos.Rows.Add(row);
                    }
                }
            }
        }
    }
}
