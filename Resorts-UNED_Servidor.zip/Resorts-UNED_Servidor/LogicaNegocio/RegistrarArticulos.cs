﻿using AccesoDatos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio
{
    public class RegistrarArticulos
    {
        public Boolean GuardarArticulo(Articulo Nuevoarticulo) 
        {
            bool ArticuloGuardado = false;

            Articulo[] Articulos = ArticuloAD.ConsultarArticulos();

            for (int i=0; i < Articulos.Length; i++) 
            {
                if (Articulos[i] != null && Articulos[i].IDArticulo == Nuevoarticulo.IDArticulo) 
                { 
                    ArticuloGuardado = true;
                    break;
                }
            }

            if(ArticuloGuardado)
            {
                return false;
            }
            else
            {
                return ArticuloAD.GuardarArticulo(Nuevoarticulo);
            }
        }

        public Articulo[] Consultar() 
        {
            return ArticuloAD.ConsultarArticulos();
        }
    }
}
