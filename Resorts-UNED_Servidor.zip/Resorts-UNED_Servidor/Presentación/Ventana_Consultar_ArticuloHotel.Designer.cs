﻿namespace Presentacion
{
    partial class Ventana_Consultar_ArticuloHotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            articuloHotelBindingSource = new BindingSource(components);
            articulosBindingSource = new BindingSource(components);
            articuloHotelBindingSource1 = new BindingSource(components);
            button1 = new Button();
            dataGridView1 = new DataGridView();
            iDAsignacionDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            fechaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            hotelDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)articuloHotelBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)articulosBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)articuloHotelBindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // articuloHotelBindingSource
            // 
            articuloHotelBindingSource.DataSource = typeof(Entidades.ArticuloHotel);
            // 
            // articulosBindingSource
            // 
            articulosBindingSource.DataMember = "Articulos";
            articulosBindingSource.DataSource = articuloHotelBindingSource;
            // 
            // articuloHotelBindingSource1
            // 
            articuloHotelBindingSource1.DataSource = typeof(Entidades.ArticuloHotel);
            // 
            // button1
            // 
            button1.Location = new Point(206, 280);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { iDAsignacionDataGridViewTextBoxColumn, fechaDataGridViewTextBoxColumn, hotelDataGridViewTextBoxColumn });
            dataGridView1.DataSource = articuloHotelBindingSource;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(269, 262);
            dataGridView1.TabIndex = 1;
            // 
            // iDAsignacionDataGridViewTextBoxColumn
            // 
            iDAsignacionDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            iDAsignacionDataGridViewTextBoxColumn.DataPropertyName = "IDAsignacion";
            iDAsignacionDataGridViewTextBoxColumn.HeaderText = "IDAsignacion";
            iDAsignacionDataGridViewTextBoxColumn.Name = "iDAsignacionDataGridViewTextBoxColumn";
            iDAsignacionDataGridViewTextBoxColumn.Width = 102;
            // 
            // fechaDataGridViewTextBoxColumn
            // 
            fechaDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            fechaDataGridViewTextBoxColumn.DataPropertyName = "Fecha";
            fechaDataGridViewTextBoxColumn.HeaderText = "Fecha";
            fechaDataGridViewTextBoxColumn.Name = "fechaDataGridViewTextBoxColumn";
            fechaDataGridViewTextBoxColumn.Width = 63;
            // 
            // hotelDataGridViewTextBoxColumn
            // 
            hotelDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            hotelDataGridViewTextBoxColumn.DataPropertyName = "Hotel";
            hotelDataGridViewTextBoxColumn.HeaderText = "Hotel";
            hotelDataGridViewTextBoxColumn.Name = "hotelDataGridViewTextBoxColumn";
            hotelDataGridViewTextBoxColumn.Width = 61;
            // 
            // Ventana_Consultar_ArticuloHotel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(298, 319);
            Controls.Add(dataGridView1);
            Controls.Add(button1);
            Name = "Ventana_Consultar_ArticuloHotel";
            Text = "Ventana_Consultar_ArticuloHotel";
            ((System.ComponentModel.ISupportInitialize)articuloHotelBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)articulosBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)articuloHotelBindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private BindingSource articuloHotelBindingSource;
        private BindingSource articulosBindingSource;
        private BindingSource articuloHotelBindingSource1;
        private Button button1;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn iDAsignacionDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn fechaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn hotelDataGridViewTextBoxColumn;
    }
}