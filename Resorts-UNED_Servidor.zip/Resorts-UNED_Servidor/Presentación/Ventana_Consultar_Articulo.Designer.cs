﻿namespace Presentacion
{
    partial class Ventana_Consultar_Articulo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dgvConsultarArticulos = new DataGridView();
            articuloBindingSource = new BindingSource(components);
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvConsultarArticulos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)articuloBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dgvConsultarArticulos
            // 
            dgvConsultarArticulos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvConsultarArticulos.Location = new Point(12, 12);
            dgvConsultarArticulos.Name = "dgvConsultarArticulos";
            dgvConsultarArticulos.Size = new Size(483, 328);
            dgvConsultarArticulos.TabIndex = 0;
            // 
            // articuloBindingSource
            // 
            articuloBindingSource.DataSource = typeof(Entidades.Articulo);
            // 
            // button1
            // 
            button1.Location = new Point(420, 354);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Ventana_Consultar_Articulo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(509, 389);
            Controls.Add(button1);
            Controls.Add(dgvConsultarArticulos);
            Name = "Ventana_Consultar_Articulo";
            Text = "Ventana_Consultar_Articulo";
            Load += Ventana_Consultar_Articulo_Load;
            ((System.ComponentModel.ISupportInitialize)dgvConsultarArticulos).EndInit();
            ((System.ComponentModel.ISupportInitialize)articuloBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvConsultarArticulos;
        private BindingSource articuloBindingSource;
        private Button button1;
    }
}