﻿/*
* Universidad Estatal a Distancia
* Escuela de Ciencias Exactas y Naturales
* Cátedra de Tecnología de Sistemas
* 
* 00830 Programación Avanzada
* Proyecto 1: Sistema de Gestión Hotelera
* Estudiante: Kabir Bonilla Vega 1 1609 0008
* Fecha: 25 de febrero de 2024
 */

/*Ventana para mostrar las asignaciones de artículos hechas a cada hotel.
 El botón insertado funciona para regresar al menú principal.*/
using Presentación;

namespace Presentacion
{
    public partial class Ventana_Consultar_ArticuloHotel : Form
    {
        public Ventana_Consultar_ArticuloHotel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Ventana_Principal MenuPrincipal = new Ventana_Principal();
            MenuPrincipal.Show();
        }
    }
}
