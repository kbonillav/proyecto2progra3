﻿namespace Presentacion
{
    partial class Ventana_Registrar_Articulo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            entrada1_articulo = new TextBox();
            label3 = new Label();
            entrada2_articulo = new TextBox();
            label4 = new Label();
            entrada3_articulo = new TextBox();
            label5 = new Label();
            entrada4_articulo = new TextBox();
            btn_registrar_articulo = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(80, 23);
            label1.Name = "label1";
            label1.Size = new Size(287, 15);
            label1.TabIndex = 0;
            label1.Text = "Ingrese la información del artículo como se le solicita";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 71);
            label2.Name = "label2";
            label2.Size = new Size(136, 15);
            label2.TabIndex = 1;
            label2.Text = "Ingrese el ID del artículo:";
            // 
            // entrada1_articulo
            // 
            entrada1_articulo.Location = new Point(186, 68);
            entrada1_articulo.Name = "entrada1_articulo";
            entrada1_articulo.Size = new Size(220, 23);
            entrada1_articulo.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(31, 128);
            label3.Name = "label3";
            label3.Size = new Size(167, 15);
            label3.TabIndex = 3;
            label3.Text = "Ingrese el nombre del artículo:";
            // 
            // entrada2_articulo
            // 
            entrada2_articulo.Location = new Point(221, 125);
            entrada2_articulo.Name = "entrada2_articulo";
            entrada2_articulo.Size = new Size(185, 23);
            entrada2_articulo.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(31, 182);
            label4.Name = "label4";
            label4.Size = new Size(160, 15);
            label4.TabIndex = 5;
            label4.Text = "Indique el precio del artículo:";
            // 
            // entrada3_articulo
            // 
            entrada3_articulo.Location = new Point(197, 179);
            entrada3_articulo.Name = "entrada3_articulo";
            entrada3_articulo.Size = new Size(209, 23);
            entrada3_articulo.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(31, 236);
            label5.Name = "label5";
            label5.Size = new Size(320, 15);
            label5.TabIndex = 7;
            label5.Text = "Indique el ID de la categoría a la que pertenecerá el artículo:";
            // 
            // entrada4_articulo
            // 
            entrada4_articulo.Location = new Point(31, 264);
            entrada4_articulo.Name = "entrada4_articulo";
            entrada4_articulo.Size = new Size(375, 23);
            entrada4_articulo.TabIndex = 8;
            // 
            // btn_registrar_articulo
            // 
            btn_registrar_articulo.Location = new Point(31, 323);
            btn_registrar_articulo.Name = "btn_registrar_articulo";
            btn_registrar_articulo.Size = new Size(75, 23);
            btn_registrar_articulo.TabIndex = 9;
            btn_registrar_articulo.Text = "Registrar";
            btn_registrar_articulo.UseVisualStyleBackColor = true;
            btn_registrar_articulo.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(331, 323);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 10;
            button2.Text = "Volver";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(176, 323);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 11;
            button3.Text = "Limpiar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Ventana_Registrar_Articulo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(445, 367);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(btn_registrar_articulo);
            Controls.Add(entrada4_articulo);
            Controls.Add(label5);
            Controls.Add(entrada3_articulo);
            Controls.Add(label4);
            Controls.Add(entrada2_articulo);
            Controls.Add(label3);
            Controls.Add(entrada1_articulo);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Ventana_Registrar_Articulo";
            Text = "Ventana_Registrar_Articulo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox entrada1_articulo;
        private Label label3;
        private TextBox entrada2_articulo;
        private Label label4;
        private TextBox entrada3_articulo;
        private Label label5;
        private TextBox entrada4_articulo;
        private Button btn_registrar_articulo;
        private Button button2;
        private Button button3;
    }
}